import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CommonModalService } from 'src/app/components/common-modal/common-modal.service';
import { SpinnerService } from 'src/app/components/spinner/spinner.service';
import { CommonPopupComponent } from 'src/app/components/common-popup/common-popup.component';
import { InfaroleService, InfraRole } from './infarole.service';

@Component({
  selector: 'app-infrarole',
  templateUrl: './infrarole.component.html',
  styleUrls: ['./infrarole.component.scss'],
})
export class InfraroleComponent implements OnInit {
  submitted = false;
  infraRoleData: InfraRole[] = [];
  infraRoleForm!: FormGroup;
  isEditMode: boolean = false;
  editIndex: number | null = null;
  searchButtonDisabled = true;

  constructor(
    private fb: FormBuilder,
    public spinnerService: SpinnerService,
    private modal: CommonModalService,
    private dialog: MatDialog,
    private infraRoleService: InfaroleService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.loadInfraRoles();
  }

  createForm() {
    this.infraRoleForm = this.fb.group({
      infraType: ['', Validators.required],
      infraRoleName: ['', Validators.required],
      activeStatus: ['', Validators.required],
      rowVersion: [''],  
      createdBy: [''],   
      createdDate: [''], 
      updatedBy: [''],   
      updatedDate: ['']  
    });
  }

  get infraType() {
    return this.infraRoleForm.get('infraType');
  }

  get infraRoleName() {
    return this.infraRoleForm.get('infraRoleName');
  }

  get activeStatus() {
    return this.infraRoleForm.get('activeStatus');
  }

  loadInfraRoles() {
    this.infraRoleService.getInfraRoles().subscribe(
      data => {
        this.infraRoleData = data;
      },
      error => {
        console.error('Error fetching InfraRoles:', error);
        this.dialog.open(CommonPopupComponent, {
          data: {
            title: 'Error',
            full_data: 'An error occurred while fetching InfraRoles.',
          },
        });
      }
    );
  }

  onSubmit() {
    this.submitted = true;
  
    if (this.infraRoleForm.invalid) {
      this.dialog.open(CommonPopupComponent, {
        data: {
          title: 'Error',
          full_data: 'Please fill out the form correctly.',
        },
      });
      return;
    }
  
    const infraRoleData: InfraRole = {
      id: this.isEditMode ? this.infraRoleData[this.editIndex!].id : 0,
      infraType: this.infraRoleForm.value.infraType,
      infraRoleName: this.infraRoleForm.value.infraRoleName,
      activeStatus: this.infraRoleForm.value.activeStatus === 'Active',
      rowVersion: this.infraRoleForm.value.rowVersion || '', 
      createdBy: this.infraRoleForm.value.createdBy || '', 
      updatedBy: this.infraRoleForm.value.updatedBy || '', 
      createdDate: this.isEditMode ? this.infraRoleData[this.editIndex!].createdDate : new Date().toISOString(),
      updatedDate: new Date().toISOString()
    };
  
    if (this.isEditMode && this.editIndex !== null) {
      // Update existing entry
      this.infraRoleService.updateInfraRole(infraRoleData.id, infraRoleData).subscribe(
        response => {
          console.log('InfraRole updated successfully:', response);
          this.modal.openModal('Success', 'Data Updated Successfully!', 'success');
          if (this.editIndex !== null) {
            this.infraRoleData[this.editIndex] = response; 
          }
          this.infraRoleForm.reset();
          this.submitted = false;
          this.isEditMode = false;
        },
        error => {
          console.error('Error updating InfraRole:', error);
          this.dialog.open(CommonPopupComponent, {
            data: {
              title: 'Error',
              full_data: 'An error occurred while updating the InfraRole.',
            },
          });
        }
      );
    } else {
      // Create new entry
      this.infraRoleService.createInfraRole(infraRoleData).subscribe(
        response => {
          console.log('InfraRole created successfully:', response);
          this.modal.openModal('Success', 'Data Uploaded Successfully!', 'success');
          this.infraRoleData.push(response);
          this.infraRoleForm.reset();
          this.submitted = false;
          this.isEditMode = false;
        },
        error => {
          console.error('Error creating InfraRole:', error);
          this.dialog.open(CommonPopupComponent, {
            data: {
              title: 'Error',
              full_data: 'An error occurred while creating the InfraRole.',
            },
          });
        }
      );
    }
  }

  onReset() {
    this.infraRoleForm.reset();
    this.submitted = false;
    this.isEditMode = false;
    this.dialog.open(CommonPopupComponent, {
      data: {
        title: 'Reset',
        full_data: 'Form has been reset.',
      },
    });
  }

  onEdit(item: InfraRole, index: number | null) {
    if (index !== null) {
      this.infraRoleForm.patchValue({
        infraType: item.infraType,
        infraRoleName: item.infraRoleName,
        activeStatus: item.activeStatus ? 'Active' : 'Inactive',
        rowVersion: item.rowVersion || '', 
        createdBy: item.createdBy || '', 
        updatedBy: item.updatedBy || '',
        createdDate: item.createdDate || '', 
        updatedDate: item.updatedDate || ''
      });
      this.isEditMode = true;
      this.editIndex = index; // Ensure editIndex is not null
    } else {
      console.error('Index is null or undefined in onEdit method');
    }
  }
  
  onDelete(item: InfraRole) {

    this.infraRoleService.deleteInfraRole(item.id).subscribe(
      (response) => {
        console.log("delete",response)
        this.loadInfraRoles();
        this.modal.openModal('Success', 'Data Deleted Successfully!', 'success');
      },
      error => {
       
        console.error('Error deleting InfraRole:', error);
        
      }
    );
  }
  

  onSearch() {

  }
}

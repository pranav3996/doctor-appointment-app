import { TestBed } from '@angular/core/testing';

import { InfaroleService } from './infarole.service';

describe('InfaroleService', () => {
  let service: InfaroleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InfaroleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
